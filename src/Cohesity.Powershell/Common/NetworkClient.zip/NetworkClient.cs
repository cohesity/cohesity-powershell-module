﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;

namespace Cohesity
{
    internal class NetworkClient
    {

        public NetworkClient()
        {
            BuildClient();
        }

        private void BuildClient()
        {
            var handler = new WebRequestHandler();

            if (SslIgnore)
            {
                handler.ServerCertificateValidationCallback = (sender, cert, chain, sslPolicyErrors) => true;
            }

            HttpClient = new HttpClient(handler);
            HttpClient.DefaultRequestHeaders.Accept.Clear();
            HttpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        private bool sslIgnore = false;
        public bool SslIgnore
        {
            get
            {
                return sslIgnore;
            }
            set
            {
                sslIgnore = value;
                BuildClient();
            }
        }

        private Uri baseUri;

        public Uri BaseUri
        {
            get
            {
                return baseUri;
            }
            set
            {
                baseUri = value;
                BuildClient();
            }
        }

        public HttpClient HttpClient { get; private set; }

        public HttpRequestMessage CreateRequest(HttpMethod method, Uri requestUri)
        {
            var request = new HttpRequestMessage(method, requestUri);
            request.Headers.Add("Authorization", $"{AccessToken.TokenType} {AccessToken.AccessToken}");
            return request;
        }

        public AccessTokenObject AccessToken { get; set; }

        public bool IsAuthenticated
        {
            get
            {
                return AccessToken != null;
            }
        }

        //public string RawAccessToken { get; set; }
    }
}
